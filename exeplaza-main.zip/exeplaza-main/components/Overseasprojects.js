import React from 'react';


const Overseasprojects = () => {
  return (
    <div className="p-8 mb-8">
            <h2 className="font-serif text-3xl text-gray-800 text-center font-semibold"> Overseas Projects </h2>
            <div className="flex justify-center"><hr className="border-b border-1 border-rose-300 w-16 mt-4"/> </div>
            <div className="flex justify-center">
              <p className="text-center font-light mt-8 font-sans text-gray-800 max-w-3xl ">
        Overseas Projects in mainly developing countries indeed have shaped EXE’s belief of “Change is Chance”. Seeking the changes of the times as business chances, we have conducted investments to what is required based on our view to future age. EXE has operated a number of projects in Myanmar, Mongolia and has assisted those countries’ development.
              </p> 
           </div>
        


    </div>
  )
}

export default Overseasprojects